public class liczby {
    static double a;
    static double b;
    static double c;
    static String znak;
}
