Projekt na cel szkolny.

1. Cel aplikacji
   
  Aplikacja ma na celu obliczanie działań matematycznych takich, jakich użytkownik żąda i są poprawne matematycznie.
  
2. Działanie aplikacji
  
  Aplikacja działa przez konsolę, czyli wszystko będzie wprowadzane tekstowo

3. Mechanizm aplikacji
  
   Interakcja aplikacji z użytkownikiem polega na podaniu wyniku działania, który użytkownik wprowadził.
   
Wersja 1.02a

Nowa funkcja:
- Obliczanie w "nieskończoność"

Planowane funkcje:
- Stworzenie prostego interfejsu graficznego

Werjsa 1.1a 11.03.2024:

\+ poprawiono obliczanie, teraz obliczanie będzie bardziej wygodne

\+ usunięcie zbędnych linijek linijek kodu bądź pozostawione powtarzające się

\= Przetworzenie kodu na mniejszą ilość błędów i lepszą czytelność

\- Jeden błąd związany z opuszczaniem programu, dano tymczasową poprawę

Wersja 1.2a 08.04.2024:

\+ dodano zabiezpieczenie przed dzieleniem przez 0.

\+ cału program został zdebugowany, nie powinno być żadnych błędów.

\+ usunięto błąd z poprzedniej wersji, już nie powinno być problemów z opuszczeniem programu
