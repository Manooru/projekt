public class Kalkulator {
    public static void main(String[] args) {
        System.out.println("Kalkulator wersja 1.0."+"\nWitaj w kalkulatorze!");
        Obliczanie.Oblicz();
    }
}